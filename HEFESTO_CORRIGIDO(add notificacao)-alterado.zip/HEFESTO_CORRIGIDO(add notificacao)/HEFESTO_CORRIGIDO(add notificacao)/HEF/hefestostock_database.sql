USE acmmn;

-- ---------------------------------------------------------------------
-- 1. Guardar o ID do pedido_fornecedor dentro de cada entrega recebida.
-- A tabela entrega_fornecedor originalmente guardava apenas fornecedor_id
-- e o nome do item, o que nao garantia o vinculo com um pedido especifico.
-- ---------------------------------------------------------------------
SET @sql_add_pedido_fornecedor_id = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE entrega_fornecedor ADD COLUMN pedido_fornecedor_id INT NULL AFTER fornecedor_id',
    'SELECT ''Coluna pedido_fornecedor_id ja existe'' AS migracao'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = 'acmmn'
    AND TABLE_NAME = 'entrega_fornecedor'
    AND COLUMN_NAME = 'pedido_fornecedor_id'
);
PREPARE stmt_add_pedido_fornecedor_id FROM @sql_add_pedido_fornecedor_id;
EXECUTE stmt_add_pedido_fornecedor_id;
DEALLOCATE PREPARE stmt_add_pedido_fornecedor_id;

SET @sql_add_fk_pedido_fornecedor = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE entrega_fornecedor ADD CONSTRAINT fk_entrega_fornecedor_pedido_fornecedor FOREIGN KEY (pedido_fornecedor_id) REFERENCES pedido_fornecedor(id)',
    'SELECT ''FK de pedido_fornecedor ja existe'' AS migracao'
  )
  FROM information_schema.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = 'acmmn'
    AND CONSTRAINT_NAME = 'fk_entrega_fornecedor_pedido_fornecedor'
);
PREPARE stmt_add_fk_pedido_fornecedor FROM @sql_add_fk_pedido_fornecedor;
EXECUTE stmt_add_fk_pedido_fornecedor;
DEALLOCATE PREPARE stmt_add_fk_pedido_fornecedor;

-- ---------------------------------------------------------------------
-- 2. Armazenar observacoes da conferencia de envio do pedido do cliente.
-- A tabela pedido_cliente nao possuia coluna para esse formulario.
-- ---------------------------------------------------------------------
SET @sql_add_observacao_envio = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE pedido_cliente ADD COLUMN observacao_envio_pedido_cliente VARCHAR(500) NULL',
    'SELECT ''Coluna observacao_envio_pedido_cliente ja existe'' AS migracao'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = 'acmmn'
    AND TABLE_NAME = 'pedido_cliente'
    AND COLUMN_NAME = 'observacao_envio_pedido_cliente'
);
PREPARE stmt_add_observacao_envio FROM @sql_add_observacao_envio;
EXECUTE stmt_add_observacao_envio;
DEALLOCATE PREPARE stmt_add_observacao_envio;

-- ---------------------------------------------------------------------
-- 3. Criar historico_producao.
-- A tabela producao guarda apenas a etapa/status atual. Esta tabela guarda
-- cada etapa anterior para que o app consiga montar uma linha do tempo real.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS historico_producao (
  id INT NOT NULL AUTO_INCREMENT,
  producao_id INT NOT NULL,
  etapa_producao VARCHAR(50) NOT NULL,
  status_producao TINYINT NOT NULL,
  acontecimento_producao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_historico_producao_producao_data (producao_id, acontecimento_producao),
  CONSTRAINT fk_historico_producao_producao
    FOREIGN KEY (producao_id) REFERENCES producao(id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb3;

-- Preenche uma primeira etapa para as producoes que ja existiam antes
-- da criacao da tabela historico_producao.
INSERT INTO historico_producao (
  producao_id,
  etapa_producao,
  status_producao,
  acontecimento_producao
)
SELECT
  p.id,
  p.etapa_producao,
  p.status_producao,
  p.acontecimento_producao
FROM producao p
WHERE NOT EXISTS (
  SELECT 1
  FROM historico_producao hp
  WHERE hp.producao_id = p.id
);

-- Ao criar uma producao, registra a primeira etapa automaticamente.
DROP TRIGGER IF EXISTS trg_historico_producao_insert;
DROP TRIGGER IF EXISTS trg_historico_producao_update;

DELIMITER $$
CREATE TRIGGER trg_historico_producao_insert
AFTER INSERT ON producao
FOR EACH ROW
BEGIN
  INSERT INTO historico_producao (
    producao_id,
    etapa_producao,
    status_producao,
    acontecimento_producao
  ) VALUES (
    NEW.id,
    NEW.etapa_producao,
    NEW.status_producao,
    NEW.acontecimento_producao
  );
END$$

-- Sempre que etapa ou status mudar, guarda um novo evento na linha do tempo.
CREATE TRIGGER trg_historico_producao_update
AFTER UPDATE ON producao
FOR EACH ROW
BEGIN
  IF OLD.etapa_producao <> NEW.etapa_producao
     OR OLD.status_producao <> NEW.status_producao THEN
    INSERT INTO historico_producao (
      producao_id,
      etapa_producao,
      status_producao,
      acontecimento_producao
    ) VALUES (
      NEW.id,
      NEW.etapa_producao,
      NEW.status_producao,
      NOW()
    );
  END IF;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 4. Reforcar a regra de negocio de vendas.
-- op_pedido_cliente so pode mudar para 2 quando houver uma producao com
-- status 2 e um estoque_final relacionado a essa producao.
-- ---------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_vendas;

DELIMITER $$
CREATE TRIGGER trg_vendas
AFTER UPDATE ON pedido_cliente
FOR EACH ROW
BEGIN
  DECLARE v_estoque_final_id INT UNSIGNED DEFAULT NULL;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_estoque_final_id = NULL;

  IF OLD.op_pedido_cliente <> NEW.op_pedido_cliente
     AND NEW.op_pedido_cliente = 2 THEN

    SELECT ef.id
      INTO v_estoque_final_id
    FROM producao pr
    INNER JOIN estoque_final ef
      ON ef.producao_id = pr.id
    WHERE pr.pedido_cliente_id = NEW.id
      AND pr.status_producao = 2
    ORDER BY pr.id DESC, ef.id DESC
    LIMIT 1;

    IF v_estoque_final_id IS NULL THEN
      SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Pedido nao pode ser concluido: producao concluida e estoque final associado sao obrigatorios.';
    END IF;

    INSERT INTO historico_vendas (
      d_entrega_historico_vendas,
      quantidade_historico_vendas,
      valor_total_historico_vendas,
      valor_unt_historico_vendas,
      prazo_final_historico_vendas,
      pedido_cliente_id,
      estoque_final_id,
      d_realizacao_historico_vendas,
      d_termino_historico_vendas
    ) VALUES (
      CURDATE(),
      NEW.quantidade_pedido_cliente,
      NEW.valor_total_pedido_cliente,
      NEW.valor_unt_pedido_cliente,
      NEW.prazo_final_pedido_cliente,
      NEW.id,
      v_estoque_final_id,
      NEW.d_realizacao_pedido_cliente,
      NOW()
    );
  END IF;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 5. Conferencia da migracao.
-- ---------------------------------------------------------------------
SHOW COLUMNS FROM entrega_fornecedor LIKE 'pedido_fornecedor_id';
SHOW COLUMNS FROM pedido_cliente LIKE 'observacao_envio_pedido_cliente';
SHOW TABLES LIKE 'historico_producao';
SHOW TRIGGERS WHERE `Trigger` IN (
  'trg_historico_producao_insert',
  'trg_historico_producao_update',
  'trg_vendas'
);

-- Observacao importante sobre valores de compra:
-- pedido_fornecedor nao possui preco unitario. Para nao inventar custos,
-- a API grava 0,00 nos campos valor_unt_entrega_fornecedor e
-- valor_total_entrrega_fornecedor até que a estrutura receba esses valores.

