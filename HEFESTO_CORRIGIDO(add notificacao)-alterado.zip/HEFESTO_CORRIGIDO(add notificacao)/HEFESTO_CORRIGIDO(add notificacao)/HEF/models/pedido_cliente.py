"""Modelo de pedido de cliente conforme tabela pedido_cliente."""
from crud.crudBase import CrudBase
from core.database import Database


class PedidoCliente(CrudBase):
    table = "pedido_cliente"
    fields = [
        "d_realizacao_pedido_cliente", "quantidade_pedido_cliente",
        "valor_unt_pedido_cliente", "valor_total_pedido_cliente",
        "prazo_final_pedido_cliente", "op_pedido_cliente",
        "funcionario_id", "cliente_id",
    ]

    def __init__(self, d_realizacao_pedido_cliente=None, quantidade_pedido_cliente=None,
                 valor_unt_pedido_cliente=None, valor_total_pedido_cliente=None,
                 prazo_final_pedido_cliente=None, op_pedido_cliente=0,
                 funcionario_id=None, cliente_id=None, **legado):
        self.d_realizacao_pedido_cliente = d_realizacao_pedido_cliente or legado.get("d_realizacao")
        self.quantidade_pedido_cliente = quantidade_pedido_cliente if quantidade_pedido_cliente is not None else legado.get("quantidade")
        self.valor_unt_pedido_cliente = valor_unt_pedido_cliente if valor_unt_pedido_cliente is not None else legado.get("valor_unt")
        self.valor_total_pedido_cliente = valor_total_pedido_cliente if valor_total_pedido_cliente is not None else legado.get("valor_total")
        self.prazo_final_pedido_cliente = prazo_final_pedido_cliente or legado.get("prazo_final")
        self.op_pedido_cliente = op_pedido_cliente
        self.funcionario_id = funcionario_id
        self.cliente_id = cliente_id

    @classmethod
    def find_all_detalhado(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT pc.*, c.nome_cliente, f.nome_funcionario,
                       ip.especificacoes_item_pedido,
                       p.nome_produto, p.dimensoes_produto
                FROM pedido_cliente pc
                INNER JOIN cliente c ON c.id = pc.cliente_id
                INNER JOIN funcionario f ON f.id = pc.funcionario_id
                LEFT JOIN item_pedido ip ON ip.pedido_cliente_id = pc.id
                LEFT JOIN produto p ON p.id = ip.produto_id
                ORDER BY pc.id ASC
            """)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()
