
from crud.crudBase import CrudBase


class entrega_fornecedor(CrudBase):
    table = "entrega_fornecedor"

    fields = [
        "valor_total_entrrega_fornecedor",
        "valor_unt_entrega_fornecedor",
        "item_entrega_fornecedor",
        "quantidadde_entrega_fornecedor",
        "observacao_entrega_fornecedor",
        "fornecedor_id",
        "status_entrega_fornecedor"
    ]

    def __init__(
        self,
        valor_total_entrrega_fornecedor=None,
        valor_unt_entrega_fornecedor=None,
        item_entrega_fornecedor=None,
        quantidadde_entrega_fornecedor=None,
        observacao_entrega_fornecedor=None,
        fornecedor_id=None,
        status_entrega_fornecedor=0
    ):
        self.valor_total_entrrega_fornecedor = valor_total_entrrega_fornecedor
        self.valor_unt_entrega_fornecedor = valor_unt_entrega_fornecedor
        self.item_entrega_fornecedor = item_entrega_fornecedor
        self.quantidadde_entrega_fornecedor = quantidadde_entrega_fornecedor
        self.observacao_entrega_fornecedor = observacao_entrega_fornecedor
        self.fornecedor_id = fornecedor_id
        self.status_entrega_fornecedor = status_entrega_fornecedor
